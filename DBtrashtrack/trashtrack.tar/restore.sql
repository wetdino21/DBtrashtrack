--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trashtrack;
--
-- Name: trashtrack; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trashtrack WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE trashtrack OWNER TO postgres;

\connect trashtrack

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_acc_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_acc_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set the ACC_UPDATED_AT to the current timestamp
    NEW.ACC_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_acc_updated_at() OWNER TO postgres;

--
-- Name: update_bk_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_bk_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.BK_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_bk_updated_at() OWNER TO postgres;

--
-- Name: update_bo_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_bo_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.BO_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_bo_updated_at() OWNER TO postgres;

--
-- Name: update_cont_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_cont_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.CONT_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_cont_updated_at() OWNER TO postgres;

--
-- Name: update_ctrl_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ctrl_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.CTRL_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ctrl_updated_at() OWNER TO postgres;

--
-- Name: update_cus_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_cus_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.CUS_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_cus_updated_at() OWNER TO postgres;

--
-- Name: update_est_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_est_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.EST_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_est_updated_at() OWNER TO postgres;

--
-- Name: update_gb_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_gb_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.GB_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_gb_updated_at() OWNER TO postgres;

--
-- Name: update_haul_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_haul_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.HAUL_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_haul_updated_at() OWNER TO postgres;

--
-- Name: update_lt_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_lt_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.LT_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_lt_updated_at() OWNER TO postgres;

--
-- Name: update_notif_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_notif_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.NOTIF_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_notif_updated_at() OWNER TO postgres;

--
-- Name: update_op_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_op_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.OP_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_op_updated_at() OWNER TO postgres;

--
-- Name: update_payment_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_payment_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.PAYMENT_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_payment_updated_at() OWNER TO postgres;

--
-- Name: update_ps_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ps_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.PS_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ps_updated_at() OWNER TO postgres;

--
-- Name: update_v_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_v_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.V_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_v_updated_at() OWNER TO postgres;

--
-- Name: update_wc_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_wc_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.WC_UPDATED_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_wc_updated_at() OWNER TO postgres;

--
-- Name: acc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acc_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acc_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_manager (
    acc_id integer DEFAULT nextval('public.acc_id_seq'::regclass) NOT NULL,
    acc_fname character varying(100),
    acc_mname character varying(100),
    acc_lname character varying(100),
    acc_password character varying(255) NOT NULL,
    acc_contact character varying(20),
    acc_email character varying(254) NOT NULL,
    acc_status character varying(50) DEFAULT 'Active'::character varying,
    acc_role character varying(50),
    acc_profile bytea,
    acc_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    acc_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    acc_otp character varying(50)
);


ALTER TABLE public.account_manager OWNER TO postgres;

--
-- Name: bo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bo_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bo_id_seq OWNER TO postgres;

--
-- Name: billing_officer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billing_officer (
    bo_id integer DEFAULT nextval('public.bo_id_seq'::regclass) NOT NULL,
    bo_fname character varying(100) NOT NULL,
    bo_mname character varying(100) NOT NULL,
    bo_lname character varying(100) NOT NULL,
    bo_password character varying(255) NOT NULL,
    bo_contact character varying(255) NOT NULL,
    bo_address character varying(255) NOT NULL,
    bo_email character varying(254) NOT NULL,
    bo_status character varying(50) DEFAULT 'Active'::character varying NOT NULL,
    bo_role character varying(50) NOT NULL,
    bo_profile bytea,
    bo_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bo_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    acc_id integer NOT NULL,
    bo_otp character varying(50)
);


ALTER TABLE public.billing_officer OWNER TO postgres;

--
-- Name: bk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bk_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bk_id_seq OWNER TO postgres;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking (
    bk_id integer DEFAULT nextval('public.bk_id_seq'::regclass) NOT NULL,
    bk_date timestamp without time zone NOT NULL,
    bk_address character varying(255) NOT NULL,
    bk_status character varying(255) NOT NULL,
    bk_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bk_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cus_id integer NOT NULL,
    wc_id integer NOT NULL
);


ALTER TABLE public.booking OWNER TO postgres;

--
-- Name: cont_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cont_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cont_id_seq OWNER TO postgres;

--
-- Name: contractual; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contractual (
    cont_id integer DEFAULT nextval('public.cont_id_seq'::regclass) NOT NULL,
    cont_business_reg bytea,
    cont_valid_id bytea,
    cont_agreement bytea,
    cont_rep_name character varying(255),
    cont_comp_name character varying(255),
    cont_status character varying(50),
    cont_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cont_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cus_id integer NOT NULL,
    acc_id integer NOT NULL
);


ALTER TABLE public.contractual OWNER TO postgres;

--
-- Name: ctrl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ctrl_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ctrl_id_seq OWNER TO postgres;

--
-- Name: control; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.control (
    ctrl_id integer DEFAULT nextval('public.ctrl_id_seq'::regclass) NOT NULL,
    ctrl_lead_days integer NOT NULL,
    ctrl_interest numeric(10,2) NOT NULL,
    ctrl_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ctrl_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bo_id integer NOT NULL
);


ALTER TABLE public.control OWNER TO postgres;

--
-- Name: cus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cus_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cus_id_seq OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    cus_id integer DEFAULT nextval('public.cus_id_seq'::regclass) NOT NULL,
    cus_fname character varying(100),
    cus_mname character varying(10),
    cus_lname character varying(100),
    cus_password character varying(255),
    cus_contact character varying(20),
    cus_address character varying(255),
    cus_email character varying(255) NOT NULL,
    cus_status character varying(255),
    cus_type character varying(100),
    cus_profile bytea,
    cus_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    cus_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    acc_id integer,
    cus_otp character varying(50),
    cus_auth_method character varying(50),
    cus_province character varying(100),
    cus_city character varying(100),
    cus_brgy character varying(100),
    cus_street character varying(255),
    cus_postal character varying(10)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: email_verification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_verification (
    email_id integer NOT NULL,
    email character varying(255) NOT NULL,
    email_code text NOT NULL,
    email_expire bigint NOT NULL,
    email_attempts integer DEFAULT 0,
    email_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.email_verification OWNER TO postgres;

--
-- Name: email_verification_email_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_verification_email_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_verification_email_id_seq OWNER TO postgres;

--
-- Name: email_verification_email_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_verification_email_id_seq OWNED BY public.email_verification.email_id;


--
-- Name: est_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.est_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.est_id_seq OWNER TO postgres;

--
-- Name: establishment_date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.establishment_date (
    est_date_id integer DEFAULT nextval('public.est_id_seq'::regclass) NOT NULL,
    est_date timestamp without time zone,
    est_trck_slip integer NOT NULL,
    est_sum_kg integer NOT NULL,
    est_no_trip integer NOT NULL,
    est_slip_pic bytea,
    est_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    est_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ps_id integer NOT NULL
);


ALTER TABLE public.establishment_date OWNER TO postgres;

--
-- Name: gb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gb_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gb_id_seq OWNER TO postgres;

--
-- Name: generate_bill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generate_bill (
    gb_id integer DEFAULT nextval('public.gb_id_seq'::regclass) NOT NULL,
    gb_desc character varying(255) NOT NULL,
    gb_sum_kilo integer NOT NULL,
    gb_unit_price numeric(10,2) NOT NULL,
    gb_num_trips integer NOT NULL,
    gb_net_vat numeric(10,2) NOT NULL,
    gb_vat_amnt numeric(10,2) NOT NULL,
    gb_tot_sales numeric(10,2) NOT NULL,
    gb_date_issued timestamp without time zone NOT NULL,
    gb_date_due timestamp without time zone NOT NULL,
    gb_interest numeric(10,2) NOT NULL,
    gb_vat numeric(10,2) NOT NULL,
    gb_total_amnt_interest numeric(10,2) NOT NULL,
    gb_date_paid timestamp without time zone NOT NULL,
    gb_upload_receipt bytea NOT NULL,
    gb_amnt_paid numeric(10,2) NOT NULL,
    gb_remain_balance numeric(10,2) NOT NULL,
    gb_over_payment numeric(10,2) NOT NULL,
    gb_bill_status character varying(100) NOT NULL,
    gb_status character varying(100) NOT NULL,
    gb_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gb_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cus_id integer NOT NULL,
    ctrl_id integer NOT NULL,
    ps_id integer NOT NULL,
    bo_id integer NOT NULL
);


ALTER TABLE public.generate_bill OWNER TO postgres;

--
-- Name: haul_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.haul_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.haul_id_seq OWNER TO postgres;

--
-- Name: hauler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hauler (
    haul_id integer DEFAULT nextval('public.haul_id_seq'::regclass) NOT NULL,
    haul_fname character varying(100),
    haul_mname character varying(10),
    haul_lname character varying(100),
    haul_password character varying(255) NOT NULL,
    haul_contact character varying(20),
    haul_address character varying(255),
    haul_email character varying(255) NOT NULL,
    haul_role character varying(50),
    haul_profile bytea,
    haul_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    haul_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    acc_id integer NOT NULL,
    haul_otp character varying(50),
    haul_auth_method character varying(50),
    haul_status character varying(50)
);


ALTER TABLE public.hauler OWNER TO postgres;

--
-- Name: lt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lt_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lt_id_seq OWNER TO postgres;

--
-- Name: location_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_tracking (
    lt_id integer DEFAULT nextval('public.lt_id_seq'::regclass) NOT NULL,
    lt_cus_latitude numeric(1000,5) NOT NULL,
    lt_cus_longitude numeric(1000,5) NOT NULL,
    lt_haul_latitude numeric(1000,5) NOT NULL,
    lt_haul_longitude numeric(1000,5) NOT NULL,
    lt_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lt_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cus_id integer NOT NULL,
    haul_id integer NOT NULL
);


ALTER TABLE public.location_tracking OWNER TO postgres;

--
-- Name: notif_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notif_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notif_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    notif_id integer DEFAULT nextval('public.notif_id_seq'::regclass) NOT NULL,
    notif_message character varying(255) NOT NULL,
    notif_status character varying(100) NOT NULL,
    notif_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notif_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    haul_id integer,
    cus_id integer,
    bo_id integer
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: op_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.op_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.op_id_seq OWNER TO postgres;

--
-- Name: operational_dispatcher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operational_dispatcher (
    op_id integer DEFAULT nextval('public.op_id_seq'::regclass) NOT NULL,
    op_fname character varying(100) NOT NULL,
    op_mname character varying(10) NOT NULL,
    op_password character varying(255) NOT NULL,
    op_contact character varying(20) NOT NULL,
    op_address character varying(255) NOT NULL,
    op_email character varying(100) NOT NULL,
    op_status character varying(50) NOT NULL,
    op_profile bytea,
    op_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    op_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    acc_id integer NOT NULL,
    op_otp character varying(50)
);


ALTER TABLE public.operational_dispatcher OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_id_seq OWNER TO postgres;

--
-- Name: payment_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_history (
    payment_id integer DEFAULT nextval('public.payment_id_seq'::regclass) NOT NULL,
    payment_amount numeric(10,2) NOT NULL,
    payment_date timestamp without time zone NOT NULL,
    payment_status character varying(100) NOT NULL,
    payment_method character varying(100) NOT NULL,
    payment_desc character varying(255) NOT NULL,
    payment_trans_id character varying(255) NOT NULL,
    payment_receipt_url character varying(255) NOT NULL,
    payment_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    payment_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gb_id integer NOT NULL
);


ALTER TABLE public.payment_history OWNER TO postgres;

--
-- Name: ps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ps_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_id_seq OWNER TO postgres;

--
-- Name: pickup_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pickup_schedule (
    ps_id integer DEFAULT nextval('public.ps_id_seq'::regclass) NOT NULL,
    ps_scheduled_date timestamp without time zone NOT NULL,
    ps_status character varying(255) NOT NULL,
    ps_slip_pic bytea NOT NULL,
    ps_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ps_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bk_id integer NOT NULL,
    haul_id integer NOT NULL,
    op_id integer NOT NULL,
    v_id integer NOT NULL
);


ALTER TABLE public.pickup_schedule OWNER TO postgres;

--
-- Name: v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.v_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.v_id_seq OWNER TO postgres;

--
-- Name: vehicle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicle (
    v_id integer DEFAULT nextval('public.v_id_seq'::regclass) NOT NULL,
    v_plate character varying(255) NOT NULL,
    v_type character varying(255) NOT NULL,
    v_status character varying(255) NOT NULL,
    v_capacity character varying(255) NOT NULL,
    v_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    v_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    op_id integer NOT NULL
);


ALTER TABLE public.vehicle OWNER TO postgres;

--
-- Name: wc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wc_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wc_id_seq OWNER TO postgres;

--
-- Name: waste_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waste_category (
    wc_id integer DEFAULT nextval('public.wc_id_seq'::regclass) NOT NULL,
    wc_name character varying(100) NOT NULL,
    wc_unit character varying(20) NOT NULL,
    wc_price numeric NOT NULL,
    wc_status character varying(50) NOT NULL,
    wc_created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    wc_updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bo_id integer NOT NULL
);


ALTER TABLE public.waste_category OWNER TO postgres;

--
-- Name: email_verification email_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_verification ALTER COLUMN email_id SET DEFAULT nextval('public.email_verification_email_id_seq'::regclass);


--
-- Data for Name: account_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_manager (acc_id, acc_fname, acc_mname, acc_lname, acc_password, acc_contact, acc_email, acc_status, acc_role, acc_profile, acc_created_at, acc_updated_at, acc_otp) FROM stdin;
\.
COPY public.account_manager (acc_id, acc_fname, acc_mname, acc_lname, acc_password, acc_contact, acc_email, acc_status, acc_role, acc_profile, acc_created_at, acc_updated_at, acc_otp) FROM '$$PATH$$/5005.dat';

--
-- Data for Name: billing_officer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billing_officer (bo_id, bo_fname, bo_mname, bo_lname, bo_password, bo_contact, bo_address, bo_email, bo_status, bo_role, bo_profile, bo_created_at, bo_updated_at, acc_id, bo_otp) FROM stdin;
\.
COPY public.billing_officer (bo_id, bo_fname, bo_mname, bo_lname, bo_password, bo_contact, bo_address, bo_email, bo_status, bo_role, bo_profile, bo_created_at, bo_updated_at, acc_id, bo_otp) FROM '$$PATH$$/5007.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking (bk_id, bk_date, bk_address, bk_status, bk_created_at, bk_updated_at, cus_id, wc_id) FROM stdin;
\.
COPY public.booking (bk_id, bk_date, bk_address, bk_status, bk_created_at, bk_updated_at, cus_id, wc_id) FROM '$$PATH$$/5009.dat';

--
-- Data for Name: contractual; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contractual (cont_id, cont_business_reg, cont_valid_id, cont_agreement, cont_rep_name, cont_comp_name, cont_status, cont_created_at, cont_updated_at, cus_id, acc_id) FROM stdin;
\.
COPY public.contractual (cont_id, cont_business_reg, cont_valid_id, cont_agreement, cont_rep_name, cont_comp_name, cont_status, cont_created_at, cont_updated_at, cus_id, acc_id) FROM '$$PATH$$/5011.dat';

--
-- Data for Name: control; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.control (ctrl_id, ctrl_lead_days, ctrl_interest, ctrl_created_at, ctrl_updated_at, bo_id) FROM stdin;
\.
COPY public.control (ctrl_id, ctrl_lead_days, ctrl_interest, ctrl_created_at, ctrl_updated_at, bo_id) FROM '$$PATH$$/5013.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (cus_id, cus_fname, cus_mname, cus_lname, cus_password, cus_contact, cus_address, cus_email, cus_status, cus_type, cus_profile, cus_created_at, cus_updated_at, acc_id, cus_otp, cus_auth_method, cus_province, cus_city, cus_brgy, cus_street, cus_postal) FROM stdin;
\.
COPY public.customer (cus_id, cus_fname, cus_mname, cus_lname, cus_password, cus_contact, cus_address, cus_email, cus_status, cus_type, cus_profile, cus_created_at, cus_updated_at, acc_id, cus_otp, cus_auth_method, cus_province, cus_city, cus_brgy, cus_street, cus_postal) FROM '$$PATH$$/5015.dat';

--
-- Data for Name: email_verification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_verification (email_id, email, email_code, email_expire, email_attempts, email_created_at) FROM stdin;
\.
COPY public.email_verification (email_id, email, email_code, email_expire, email_attempts, email_created_at) FROM '$$PATH$$/5037.dat';

--
-- Data for Name: establishment_date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.establishment_date (est_date_id, est_date, est_trck_slip, est_sum_kg, est_no_trip, est_slip_pic, est_created_at, est_updated_at, ps_id) FROM stdin;
\.
COPY public.establishment_date (est_date_id, est_date, est_trck_slip, est_sum_kg, est_no_trip, est_slip_pic, est_created_at, est_updated_at, ps_id) FROM '$$PATH$$/5017.dat';

--
-- Data for Name: generate_bill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generate_bill (gb_id, gb_desc, gb_sum_kilo, gb_unit_price, gb_num_trips, gb_net_vat, gb_vat_amnt, gb_tot_sales, gb_date_issued, gb_date_due, gb_interest, gb_vat, gb_total_amnt_interest, gb_date_paid, gb_upload_receipt, gb_amnt_paid, gb_remain_balance, gb_over_payment, gb_bill_status, gb_status, gb_created_at, gb_updated_at, cus_id, ctrl_id, ps_id, bo_id) FROM stdin;
\.
COPY public.generate_bill (gb_id, gb_desc, gb_sum_kilo, gb_unit_price, gb_num_trips, gb_net_vat, gb_vat_amnt, gb_tot_sales, gb_date_issued, gb_date_due, gb_interest, gb_vat, gb_total_amnt_interest, gb_date_paid, gb_upload_receipt, gb_amnt_paid, gb_remain_balance, gb_over_payment, gb_bill_status, gb_status, gb_created_at, gb_updated_at, cus_id, ctrl_id, ps_id, bo_id) FROM '$$PATH$$/5019.dat';

--
-- Data for Name: hauler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hauler (haul_id, haul_fname, haul_mname, haul_lname, haul_password, haul_contact, haul_address, haul_email, haul_role, haul_profile, haul_created_at, haul_updated_at, acc_id, haul_otp, haul_auth_method, haul_status) FROM stdin;
\.
COPY public.hauler (haul_id, haul_fname, haul_mname, haul_lname, haul_password, haul_contact, haul_address, haul_email, haul_role, haul_profile, haul_created_at, haul_updated_at, acc_id, haul_otp, haul_auth_method, haul_status) FROM '$$PATH$$/5021.dat';

--
-- Data for Name: location_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location_tracking (lt_id, lt_cus_latitude, lt_cus_longitude, lt_haul_latitude, lt_haul_longitude, lt_created_at, lt_updated_at, cus_id, haul_id) FROM stdin;
\.
COPY public.location_tracking (lt_id, lt_cus_latitude, lt_cus_longitude, lt_haul_latitude, lt_haul_longitude, lt_created_at, lt_updated_at, cus_id, haul_id) FROM '$$PATH$$/5023.dat';

--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (notif_id, notif_message, notif_status, notif_created_at, notif_updated_at, haul_id, cus_id, bo_id) FROM stdin;
\.
COPY public.notification (notif_id, notif_message, notif_status, notif_created_at, notif_updated_at, haul_id, cus_id, bo_id) FROM '$$PATH$$/5025.dat';

--
-- Data for Name: operational_dispatcher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operational_dispatcher (op_id, op_fname, op_mname, op_password, op_contact, op_address, op_email, op_status, op_profile, op_created_at, op_updated_at, acc_id, op_otp) FROM stdin;
\.
COPY public.operational_dispatcher (op_id, op_fname, op_mname, op_password, op_contact, op_address, op_email, op_status, op_profile, op_created_at, op_updated_at, acc_id, op_otp) FROM '$$PATH$$/5027.dat';

--
-- Data for Name: payment_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_history (payment_id, payment_amount, payment_date, payment_status, payment_method, payment_desc, payment_trans_id, payment_receipt_url, payment_created_at, payment_updated_at, gb_id) FROM stdin;
\.
COPY public.payment_history (payment_id, payment_amount, payment_date, payment_status, payment_method, payment_desc, payment_trans_id, payment_receipt_url, payment_created_at, payment_updated_at, gb_id) FROM '$$PATH$$/5029.dat';

--
-- Data for Name: pickup_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pickup_schedule (ps_id, ps_scheduled_date, ps_status, ps_slip_pic, ps_created_at, ps_updated_at, bk_id, haul_id, op_id, v_id) FROM stdin;
\.
COPY public.pickup_schedule (ps_id, ps_scheduled_date, ps_status, ps_slip_pic, ps_created_at, ps_updated_at, bk_id, haul_id, op_id, v_id) FROM '$$PATH$$/5031.dat';

--
-- Data for Name: vehicle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicle (v_id, v_plate, v_type, v_status, v_capacity, v_created_at, v_updated_at, op_id) FROM stdin;
\.
COPY public.vehicle (v_id, v_plate, v_type, v_status, v_capacity, v_created_at, v_updated_at, op_id) FROM '$$PATH$$/5033.dat';

--
-- Data for Name: waste_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waste_category (wc_id, wc_name, wc_unit, wc_price, wc_status, wc_created_at, wc_updated_at, bo_id) FROM stdin;
\.
COPY public.waste_category (wc_id, wc_name, wc_unit, wc_price, wc_status, wc_created_at, wc_updated_at, bo_id) FROM '$$PATH$$/5035.dat';

--
-- Name: acc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acc_id_seq', 1002, true);


--
-- Name: bk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bk_id_seq', 1000, false);


--
-- Name: bo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bo_id_seq', 1004, true);


--
-- Name: cont_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cont_id_seq', 1000, false);


--
-- Name: ctrl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ctrl_id_seq', 100, false);


--
-- Name: cus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cus_id_seq', 1076, true);


--
-- Name: email_verification_email_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_verification_email_id_seq', 118, true);


--
-- Name: est_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.est_id_seq', 1000, false);


--
-- Name: gb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gb_id_seq', 1000, false);


--
-- Name: haul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.haul_id_seq', 1020, true);


--
-- Name: lt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lt_id_seq', 1000, false);


--
-- Name: notif_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notif_id_seq', 1004, true);


--
-- Name: op_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.op_id_seq', 1000, false);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_id_seq', 1000, false);


--
-- Name: ps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ps_id_seq', 1000, false);


--
-- Name: v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.v_id_seq', 1000, false);


--
-- Name: wc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wc_id_seq', 104, true);


--
-- Name: account_manager account_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_manager
    ADD CONSTRAINT account_manager_pkey PRIMARY KEY (acc_id);


--
-- Name: billing_officer billing_officer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_officer
    ADD CONSTRAINT billing_officer_pkey PRIMARY KEY (bo_id);


--
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (bk_id);


--
-- Name: contractual contractual_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contractual
    ADD CONSTRAINT contractual_pkey PRIMARY KEY (cont_id);


--
-- Name: control control_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.control
    ADD CONSTRAINT control_pkey PRIMARY KEY (ctrl_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (cus_id);


--
-- Name: email_verification email_verification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_verification
    ADD CONSTRAINT email_verification_pkey PRIMARY KEY (email_id);


--
-- Name: establishment_date establishment_date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establishment_date
    ADD CONSTRAINT establishment_date_pkey PRIMARY KEY (est_date_id);


--
-- Name: generate_bill generate_bill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generate_bill
    ADD CONSTRAINT generate_bill_pkey PRIMARY KEY (gb_id);


--
-- Name: hauler hauler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hauler
    ADD CONSTRAINT hauler_pkey PRIMARY KEY (haul_id);


--
-- Name: location_tracking location_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_tracking
    ADD CONSTRAINT location_tracking_pkey PRIMARY KEY (lt_id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (notif_id);


--
-- Name: operational_dispatcher operational_dispatcher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operational_dispatcher
    ADD CONSTRAINT operational_dispatcher_pkey PRIMARY KEY (op_id);


--
-- Name: payment_history payment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_history
    ADD CONSTRAINT payment_history_pkey PRIMARY KEY (payment_id);


--
-- Name: pickup_schedule pickup_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickup_schedule
    ADD CONSTRAINT pickup_schedule_pkey PRIMARY KEY (ps_id);


--
-- Name: customer unique_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT unique_email UNIQUE (cus_email);


--
-- Name: vehicle vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_pkey PRIMARY KEY (v_id);


--
-- Name: waste_category waste_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waste_category
    ADD CONSTRAINT waste_category_pkey PRIMARY KEY (wc_id);


--
-- Name: account_manager set_acc_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_acc_updated_at BEFORE UPDATE ON public.account_manager FOR EACH ROW EXECUTE FUNCTION public.update_acc_updated_at();


--
-- Name: booking set_bk_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_bk_updated_at BEFORE UPDATE ON public.booking FOR EACH ROW EXECUTE FUNCTION public.update_bk_updated_at();


--
-- Name: billing_officer set_bo_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_bo_updated_at BEFORE UPDATE ON public.billing_officer FOR EACH ROW EXECUTE FUNCTION public.update_bo_updated_at();


--
-- Name: contractual set_cont_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_cont_updated_at BEFORE UPDATE ON public.contractual FOR EACH ROW EXECUTE FUNCTION public.update_bo_updated_at();


--
-- Name: control set_ctrl_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_ctrl_updated_at BEFORE UPDATE ON public.control FOR EACH ROW EXECUTE FUNCTION public.update_ctrl_updated_at();


--
-- Name: customer set_cus_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_cus_updated_at BEFORE UPDATE ON public.customer FOR EACH ROW EXECUTE FUNCTION public.update_cus_updated_at();


--
-- Name: establishment_date set_est_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_est_updated_at BEFORE UPDATE ON public.establishment_date FOR EACH ROW EXECUTE FUNCTION public.update_est_updated_at();


--
-- Name: generate_bill set_gb_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_gb_updated_at BEFORE UPDATE ON public.generate_bill FOR EACH ROW EXECUTE FUNCTION public.update_gb_updated_at();


--
-- Name: hauler set_haul_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_haul_updated_at BEFORE UPDATE ON public.hauler FOR EACH ROW EXECUTE FUNCTION public.update_haul_updated_at();


--
-- Name: location_tracking set_lt_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_lt_updated_at BEFORE UPDATE ON public.location_tracking FOR EACH ROW EXECUTE FUNCTION public.update_lt_updated_at();


--
-- Name: notification set_notif_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_notif_updated_at BEFORE UPDATE ON public.notification FOR EACH ROW EXECUTE FUNCTION public.update_notif_updated_at();


--
-- Name: operational_dispatcher set_op_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_op_updated_at BEFORE UPDATE ON public.operational_dispatcher FOR EACH ROW EXECUTE FUNCTION public.update_op_updated_at();


--
-- Name: payment_history set_payment_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_payment_updated_at BEFORE UPDATE ON public.payment_history FOR EACH ROW EXECUTE FUNCTION public.update_payment_updated_at();


--
-- Name: pickup_schedule set_ps_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_ps_updated_at BEFORE UPDATE ON public.pickup_schedule FOR EACH ROW EXECUTE FUNCTION public.update_ps_updated_at();


--
-- Name: vehicle set_v_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_v_updated_at BEFORE UPDATE ON public.vehicle FOR EACH ROW EXECUTE FUNCTION public.update_v_updated_at();


--
-- Name: waste_category set_wc_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_wc_updated_at BEFORE UPDATE ON public.waste_category FOR EACH ROW EXECUTE FUNCTION public.update_wc_updated_at();


--
-- Name: billing_officer billing_officer_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_officer
    ADD CONSTRAINT billing_officer_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account_manager(acc_id);


--
-- Name: booking booking_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id);


--
-- Name: booking booking_wc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_wc_id_fkey FOREIGN KEY (wc_id) REFERENCES public.waste_category(wc_id);


--
-- Name: contractual contractual_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contractual
    ADD CONSTRAINT contractual_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account_manager(acc_id);


--
-- Name: contractual contractual_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contractual
    ADD CONSTRAINT contractual_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id);


--
-- Name: control control_bo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.control
    ADD CONSTRAINT control_bo_id_fkey FOREIGN KEY (bo_id) REFERENCES public.billing_officer(bo_id);


--
-- Name: customer customer_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account_manager(acc_id);


--
-- Name: establishment_date establishment_date_ps_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establishment_date
    ADD CONSTRAINT establishment_date_ps_id_fkey FOREIGN KEY (ps_id) REFERENCES public.pickup_schedule(ps_id);


--
-- Name: generate_bill generate_bill_bo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generate_bill
    ADD CONSTRAINT generate_bill_bo_id_fkey FOREIGN KEY (bo_id) REFERENCES public.billing_officer(bo_id);


--
-- Name: generate_bill generate_bill_ctrl_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generate_bill
    ADD CONSTRAINT generate_bill_ctrl_id_fkey FOREIGN KEY (ctrl_id) REFERENCES public.control(ctrl_id);


--
-- Name: generate_bill generate_bill_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generate_bill
    ADD CONSTRAINT generate_bill_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id);


--
-- Name: generate_bill generate_bill_ps_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generate_bill
    ADD CONSTRAINT generate_bill_ps_id_fkey FOREIGN KEY (ps_id) REFERENCES public.pickup_schedule(ps_id);


--
-- Name: hauler hauler_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hauler
    ADD CONSTRAINT hauler_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account_manager(acc_id);


--
-- Name: location_tracking location_tracking_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_tracking
    ADD CONSTRAINT location_tracking_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id);


--
-- Name: location_tracking location_tracking_haul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_tracking
    ADD CONSTRAINT location_tracking_haul_id_fkey FOREIGN KEY (haul_id) REFERENCES public.hauler(haul_id);


--
-- Name: notification notification_bo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_bo_id_fkey FOREIGN KEY (bo_id) REFERENCES public.billing_officer(bo_id);


--
-- Name: notification notification_cus_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_cus_id_fkey FOREIGN KEY (cus_id) REFERENCES public.customer(cus_id);


--
-- Name: notification notification_haul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_haul_id_fkey FOREIGN KEY (haul_id) REFERENCES public.hauler(haul_id);


--
-- Name: operational_dispatcher operational_dispatcher_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operational_dispatcher
    ADD CONSTRAINT operational_dispatcher_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.account_manager(acc_id);


--
-- Name: payment_history payment_history_gb_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_history
    ADD CONSTRAINT payment_history_gb_id_fkey FOREIGN KEY (gb_id) REFERENCES public.generate_bill(gb_id);


--
-- Name: pickup_schedule pickup_schedule_bk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickup_schedule
    ADD CONSTRAINT pickup_schedule_bk_id_fkey FOREIGN KEY (bk_id) REFERENCES public.booking(bk_id);


--
-- Name: pickup_schedule pickup_schedule_haul_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickup_schedule
    ADD CONSTRAINT pickup_schedule_haul_id_fkey FOREIGN KEY (haul_id) REFERENCES public.hauler(haul_id);


--
-- Name: pickup_schedule pickup_schedule_op_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickup_schedule
    ADD CONSTRAINT pickup_schedule_op_id_fkey FOREIGN KEY (op_id) REFERENCES public.operational_dispatcher(op_id);


--
-- Name: pickup_schedule pickup_schedule_v_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pickup_schedule
    ADD CONSTRAINT pickup_schedule_v_id_fkey FOREIGN KEY (v_id) REFERENCES public.vehicle(v_id);


--
-- Name: vehicle vehicle_op_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_op_id_fkey FOREIGN KEY (op_id) REFERENCES public.operational_dispatcher(op_id);


--
-- Name: waste_category waste_category_bo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waste_category
    ADD CONSTRAINT waste_category_bo_id_fkey FOREIGN KEY (bo_id) REFERENCES public.billing_officer(bo_id);


--
-- PostgreSQL database dump complete
--

